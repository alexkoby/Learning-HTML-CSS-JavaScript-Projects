function echo(string, num){
    while(num--){
        console.log(string);
    }
}

let x = 5;
echo("Tater Tots", x);

console.log("X is now: " + x)