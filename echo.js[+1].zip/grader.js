function average(testScores){
    var totalScore = 0;
    for(var i = 0; i < testScores.length; i++){
        totalScore += testScores[i];
    }
    
    return Math.round((totalScore / testScores.length)) ;
}


var scores = [55, 25, 62, 84, 95, 99, 99];
console.log(average(scores));
console.log((55 + 25 + 62 + 84 + 95 + 99 + 99) / scores.length);